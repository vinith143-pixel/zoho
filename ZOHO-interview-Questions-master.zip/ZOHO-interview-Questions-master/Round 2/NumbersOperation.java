public class NumbersOperation {
    public static void main(String[] args) {
        
    }
}
// Intput: 
// 12345*+-+
//6